"""Population-scoped analysis primitives."""
from .base import PopulationVariable, VariableMeta

__all__ = ["PopulationVariable", "VariableMeta"]
