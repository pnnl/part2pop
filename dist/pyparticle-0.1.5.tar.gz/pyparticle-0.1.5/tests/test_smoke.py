def test_import():
    import pyparticle 
