#!/usr/bin/env python
# >>> RELEASE KIT START
from setuptools import setup
setup()
# <<< RELEASE KIT END
